// -- Imports and stuff --

#include <iostream>
#include <stdlib.h>
#include <string>
#include <ctime>
#include <vector>
#include <windows.h>
#include<string.h>
#include<cstring>
#pragma comment(lib, "Winmm.lib")
using namespace std;

 // -- global vars --
int bCount;
int around = 0;
int c = 0;
int bRound = 0;
int isTrue = 0;
int maxBombs = 55;
int minBombs = 10;
bool won = false;
bool died = false;
std::vector<int> bombsX(0);
std::vector<int> bombsY(0);
int userX = 0;
bool endIf = false;
int userY = 0;
int uX2 = 0;
char playerChar = 'O';
char playerTrail = 'x';
int uY2 = 0;

string lines[10] = {"|O| | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | | |",
"| | | | | | | | | | | | | | |W|",
"| | | | | | | | | | | | | | |I|",
"| | | | | | | | | | | | | | |N|",};
string userMove = "";
//  -- functions --
void drawField(){

    std::cout << "______________________________" << std::endl;

    std::cout << "-------------------------------" << std::endl;
    for(c = 0;c <= 9; c++){
        std::cout << lines[c] << endl;
    }
    std::cout << "______________________________" << std::endl;
    std::cout << "-------------------------------" << std::endl;
}
void moveCharacter(string dir){
    for(unsigned int i=0;i<dir.length();i++){
        dir[i] = tolower(dir[i]);
    }
    if(dir == "d"){
        for(int i = 0; i < 31; i++) {
            int abc = userX + 3;
            if(i == abc && endIf != true) {
                lines[userY].at(i) = playerChar;
                lines[userY].at(i-2) = playerTrail;
                userX += 2;
                uX2 ++;
                endIf = true;
            }
        }
    }
    if(dir == "w" && userY > 0){
        userY -= 1;
        for(int i = 0; i < 31; i++) {
            if(i == userX + 1 && endIf != true) {
                lines[userY].at(i) = playerChar;
                if(userY < 9){
                    lines[userY+1].at(i) = playerTrail;
                }
                endIf = true;
            }
        }
        uY2 -= 1;
    }
    if(dir == "a" && userX > 1){
        for(int i = 0; i < 31; i++) {
            int abc = userX - 1;
            if(i == abc && endIf == false) {
                lines[userY].at(i) = playerChar;
                lines[userY].at(i+2) = playerTrail;
                userX -= 2;
                endIf = true;
            }
        }
        uX2 -= 1;
    }
    if(dir == "s" && userY < 9){
        userY += 1;
        for(int i = 0; i < 31; i++) {
            if(i == userX + 1 && endIf != true) {
                lines[userY].at(i) = playerChar;
                lines[userY-1].at(i) = playerTrail;
                endIf = true;
            }
        }
        uY2++;
    }
    if(endIf != true){
        sndPlaySound("Assets/NO.wav", SND_FILENAME | SND_ASYNC);
    }
    endIf = false;
}
// int fieldSize; not added yet
int isBombThere(int x,int y){
    int lSize = bombsX.size();
    int i;
    int bombsAround;
    if (lSize >= 1){
        for(int i = 0; i < bombsX.size(); i++){ // loops through every bomb that exists
            if(bombsX.operator[](i) == x && bombsY.operator[](i) == y){ // if the bombs X and Y pos is the same as the users
                return true;
            }
            if(bombsX.operator[](i) == x || bombsX.operator[](i) == x +1|| bombsX.operator[](i) == x - 1){ // checks if the bomb is in a 3x3 grid around the player
                if(bombsY.operator[](i) == y || bombsY.operator[](i) == y + 1 || bombsY.operator[](i) == y - 1){
                    bombsAround++;
                }
            }
        }
    }if(y < 10 && y > 6 && x < 15 && x > 13){
        return 77;
    }
    bRound = bombsAround;
    return false; // return false if it completes
}
void buildField(){
    userX = 0;
    userY = 0;
    uX2 = 0;
    uY2 = 0;
    int i;
    int x;
    int maxX = 15;
    int maxY = 10;
    unsigned seed = time(0);
    srand(seed);
    if(bCount <= minBombs){
       bCount = minBombs;
    }
    else{if(bCount >=maxBombs){maxBombs = 50;}}
    int currentLine = 1;
    int currentSpot = 1;
    for(i = 1; i <= bCount; i++){
        int rX = (rand() % (maxX - 1 + 1)) + 1;
        int rY = (rand() % (maxY - 1 + 1)) + 1;
        if(isBombThere(rX,rY)!= 1){
            bombsX.push_back(rX);
            bombsY.push_back(rY);
        }
    };
    while(won != true){
        if(isBombThere(uX2,uY2) == true){
            won = true;
            died = true;
        }else{
            if(isBombThere(uX2,uY2) == 77){
                won = true;

            }else{
                drawField();
                isBombThere(uX2,uY2);
                std::cout << "Bombs around:"<< bRound << std::endl;
                std::cout << "Make a move" << std::endl;
                std::cout << "W = forward, A = Left, S = Backward,D = Right" << std::endl;
                //cout << bombsX[1] << endl << bombsY[1] << endl;
                std::cin >> userMove;
                moveCharacter(userMove);
                system("cls");
            }
        }
    }
}
void bombCount(){
    std:cout << "How many bombs should there be?(" << minBombs << "-" << maxBombs << ")" << endl;
    std::cin >> bCount;
    system("cls");
}

int main(){
    bombCount();
    buildField();
    if(died){
        cout << "You died! R.I.P" << endl;
        string inputStuff;
        sndPlaySound("Assets/death.wav", SND_FILENAME | SND_ASYNC);
        cout << "Enter something to exit the program." << endl;
        std::cin >> inputStuff;
    }else{
        cout << "You won! Congratulations." << endl;
        string inputStuff;
        sndPlaySound("Assets/victory.wav", SND_FILENAME | SND_ASYNC);
        cout << "Enter something to exit the program." << endl;
        std::cin >> inputStuff;
    }
    return 1337;
}
