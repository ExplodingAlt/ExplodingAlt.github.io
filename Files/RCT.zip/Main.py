import sys, pygame, pygame.freetype
import random
import time
import threading
import math

pygame.init()



global size
size = width, height = 600, 1000

clock = pygame.time.Clock()

timePassed = 0

screen = pygame.display.set_mode(size,pygame.RESIZABLE)

pygame.display.set_caption('A Regular Christmas Tree')

gameIcon = pygame.image.load('Assets/icon.png')

pygame.display.set_icon(gameIcon)

timeRequired = random.randint(55,95)
snowflakeImg = pygame.image.load("Assets/snowflake.png")
TreeSizeX = width
TreeSizeY = math.floor(height-height/9)
TreeImg = pygame.image.load("Assets/tree.png")
Rotation = 0
Tree = pygame.transform.rotate(pygame.transform.scale(TreeImg, (TreeSizeX, TreeSizeY)),Rotation)
TreeX = width/2-TreeSizeX/2
TreeY = height-TreeSizeY
TreeOffImg = pygame.image.load("Assets/treeOff.png")
Snowing = False
Flickering = False

Cukecans = False

Sparks = [
	
]

Snowflakes = []
 
timePassedSinceLastEvent = 0

class Spark(threading.Thread):
	def __init__(self, thread_name, thread_ID):
		threading.Thread.__init__(self)
		self.thread_name = thread_name
		self.thread_ID = thread_ID
	def run(self):
		global timePassedSinceLastEvent
		timePassedSinceLastEvent = 0
		global TreeImg
		global Flickering
		Flickering = True
		Rotation = 0
		if not pygame.mixer.music.get_busy():
			pygame.mixer.music.set_volume(0.1)
			pygame.mixer.music.load('Assets/Electric.wav')
			pygame.mixer.music.play()
		TreeImg = pygame.image.load("Assets/tree.png")
		for x in range(random.randint(3,5)):
			Sparks.append(
				{
					"img" : pygame.image.load("Assets/spark"+str(random.randint(1,2))+".png"),
					"position" : (random.randint(width-50,width),random.randint(math.floor(height-height/3),height))
				}
			)
			time.sleep(0.1)
			Sparks.clear()
		time.sleep(1.5)
		Flickering = False

		if not pygame.mixer.music.get_busy():
			pygame.mixer.music.stop()
		if random.randint(1,6) == 1:			
			TreeImg = pygame.image.load("Assets/treeBlue.png")
		elif random.randint(1,10) == 1:			
			TreeImg = pygame.image.load("Assets/binaryTree.png")
		elif random.randint(1,10) == 1:
			Rotation = 180
			TreeImg = pygame.image.load("Assets/binaryTree.png")
		else:
			TreeImg = pygame.image.load("Assets/tree.png")
		global timeRequired
		timeRequired = random.randint(90,130)
def snow():	
	timePassedSinceLastEvent = 0
	if len(Snowflakes) > 0:
		return False
	for x in range(math.floor(height/25)):
		timeRequired = random.randint(90,130)
		size = random.randint(math.floor(height/25),10+math.floor(height/25))
		if Cukecans:
			size = math.floor(height/5)
		Snowflakes.append({
			"img" : pygame.transform.scale(snowflakeImg, (size, size)),
			"position" : {"X" : random.randint(1,screen.get_size()[0]), "Y" : random.randint(-screen.get_size()[1],-30)}
		})
cheatCodeTypedIn = ""
cheatCode = "01189998819991197253"
while True:
	screen.fill("#960014")

	for event in pygame.event.get():		

		if event.type == pygame.QUIT: sys.exit()

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_SPACE:
				upKeyState = not upKeyState
			elif event.key == pygame.K_f:
				screen = pygame.display.set_mode(size,pygame.FULLSCREEN)
				pygame.display.update()
			elif event.key == pygame.K_ESCAPE:
				screen = pygame.display.set_mode(size,pygame.RESIZABLE)
				pygame.display.update()
			else:
				cheatCodeTypedIn += event.unicode
				if cheatCodeTypedIn == cheatCode:
					pygame.mixer.music.set_volume(0.5)
					pygame.mixer.music.load('Assets/0118.wav')
					pygame.mixer.music.play()
					snowflakeImg = pygame.image.load("Assets/Cuke.png")	
					Snowflakes.clear()
					Cukecans = True
					snow()

				else:
					
					if len(cheatCodeTypedIn) < len(cheatCode):
						for x in range(len(cheatCodeTypedIn)):
							if cheatCodeTypedIn[x] != cheatCode[x]:
								cheatCodeTypedIn = ""	
					else:
						cheatCodeTypedIn = ""			



	if timePassedSinceLastEvent > timeRequired:
		if random.randint(1,2) == 1:
			Spark("SparkThread",1).start()
		elif timePassedSinceLastEvent > timeRequired:
			snow()

	for spark in Sparks:
		screen.blit(spark["img"],spark["position"])
	for snowflake in Snowflakes:
		screen.blit(snowflake["img"],(snowflake["position"]["X"],snowflake["position"]["Y"]))
		snowflake["position"]["Y"] += screen.get_size()[1]/500
		if snowflake["position"]["Y"] > screen.get_size()[1]:
			Snowflakes.remove(snowflake)
	if Flickering == True:
		if random.randint(1,10) == 1:
			screen.blit(pygame.transform.rotate(pygame.transform.scale(TreeImg, (TreeSizeY, TreeSizeX)),Rotation),(TreeX,TreeY))
		else:
			screen.blit(pygame.transform.rotate(pygame.transform.scale(TreeOffImg, (TreeSizeY, TreeSizeX)),Rotation),(TreeX,TreeY))
	else:
		screen.blit(pygame.transform.rotate(pygame.transform.scale(TreeImg, (TreeSizeY, TreeSizeX)),Rotation),(TreeX,TreeY))

	pygame.display.update()
	height,width =  screen.get_size()
	TreeX = width/2-TreeSizeX/2.15
	TreeY = height-TreeSizeY
	TreeSizeX = width
	TreeSizeY = math.floor(height-height/9)
	timePassed += 1
	timePassedSinceLastEvent += 0.1
	clock.tick(60)